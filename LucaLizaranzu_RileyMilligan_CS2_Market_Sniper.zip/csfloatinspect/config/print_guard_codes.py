import os
from steamguard import SteamMobile

credentials = {
    'Scrungly2': 'jfc93a\'s81`~fd-7dk3',
    'Scrungly3': 'cdk54"F95\'cvS\'f04dD',  # Escaped backslash here
    'Scrungly4': '*hD6DJM1~D9v.z3,j',
}

for username, password in credentials.items():
    # Initialize SteamMobile for each user
    mobile = SteamMobile(username, password)

    # Load the mobile data (ensure you have the appropriate exported data file)
    try:
        mobile_data = mobile.load_exported_data(f'{mobile.account_name}_mobile.json')
        mobile.load_mobile(mobile_data)

        # Generate the Steam Guard code
        guard_code = mobile.generate_steam_guard_code()
        print(f"User {username} guard code: {guard_code}")
    except Exception as e:
        print(f"Error processing user {username}: {e}")
        guard_code = ''  # If there's an error, set the auth to empty

    # Escape the password and guard_code
    password_escaped = password.replace("'", "\\'")

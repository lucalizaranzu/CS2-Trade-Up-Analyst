from steamguard import SteamMobile

username = "scrungly2"
password = "jfc93a's81`~fd-7dk3"

mobile = SteamMobile(username,password)

mobile_data = mobile.load_exported_data(f'{mobile.account_name}_mobile.json')
mobile.load_mobile(mobile_data)

guard_code = mobile.generate_steam_guard_code()
print(mobile_data)
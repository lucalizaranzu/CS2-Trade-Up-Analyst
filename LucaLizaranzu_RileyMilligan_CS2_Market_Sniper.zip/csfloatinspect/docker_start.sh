#!/bin/bash

# Ensure steam_data directory exists
if [ ! -d ./config/steam_data ]; then
    mkdir -p ./config/steam_data
fi

# Start the server
node index.js -c ./config/config.js -s ./config/steam_data
